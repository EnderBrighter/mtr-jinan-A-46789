import json,pathlib,math
from PIL import Image
r=pathlib.Path('assets/mtr/jinan_line4');b=json.loads((r/'models/doors.bbmodel').read_text());out={g['name']:g['children'] for g in b['outliner']};els={e['uuid']:e for e in b['elements']}
# Native BBMODEL: draw coordinates (-x,-y,z), interaction bounds (x,y,z).
# Both use the same Z axis. Test actual panel aperture and correspondence with source OBJ geometry.
scene=json.loads(pathlib.Path('source/geometry.json').read_text())['cab']
for g,ids in out.items():
 src=[v for f in scene[g] for v in f['v']];bb=[v for uid in ids for v in [els[uid]['from'],els[uid]['to']]]
 for k,sign in enumerate([-1,1,-1]):
  native=sorted([min(v[k] for v in bb)/16,max(v[k] for v in bb)/16]);expected=sorted([min(v[k] for v in src)*sign,max(v[k] for v in src)*sign]);assert all(abs(a-c)<1e-6 for a,c in zip(native,expected)),g
for flip in [False,True]:
 p=json.loads((r/'properties'/('doors_reverse.json' if flip else 'doors.json')).read_text())
 for side in ['l','r']:
  for i in range(5):
   pair=[]
   for leaf in ['a','b']:
    g=f'door_{side}_{i}_{leaf}';vs=[v for uid in out[g] for v in [els[uid]['from'],els[uid]['to']]];lo=min(v[2] for v in vs)/16;hi=max(v[2] for v in vs)/16
    if flip:lo,hi=-hi,-lo
    part=next(t for t in p['parts'] if t['names']==[g]);dz=part['doorZMultiplier']/16*(-1 if flip else 1);pair.append((lo,hi,dz))
   for step in range(101):
    t=step/100;intervals=sorted([(lo+dz*t,hi+dz*t) for lo,hi,dz in pair]);assert intervals[0][1]<=intervals[1][0]+1e-6,(side,i,step)
   intervals=sorted([(lo+dz,hi+dz) for lo,hi,dz in pair]);assert abs(intervals[1][0]-intervals[0][1]-1.5)<.02
# Match each opaque leaf to its native doorway using MTR's closest-interval metric.
interaction=json.loads((r/'models/interaction.bbmodel').read_text())
ways=[e for e in interaction['elements'] if e['name'].startswith('way_')]
def axis_distance(a,b,c,d):
 return max(0,c-b,a-d)
for g,ids in out.items():
 if g.endswith('_glass'):continue
 vs=[v for uid in ids for v in [els[uid]['from'],els[uid]['to']]]
 lo=[min(v[k] for v in vs)/16 for k in range(3)];hi=[max(v[k] for v in vs)/16 for k in range(3)]
 def distance(w):
  a=[v/16 for v in w['from']];b=[v/16 for v in w['to']];a[1]+=1;b[1]+=1
  return sum(axis_distance(lo[k],hi[k],a[k],b[k]) for k in range(3))
 w=min(ways,key=distance);native_side=1 if lo[0]>0 else -1
 assert w['name'].split('_')[1]==str(native_side),(g,w['name'])
 assert abs((w['from'][2]+w['to'][2])/32-(lo[2]+hi[2])/2)<1,(g,w['name'])
for v in json.loads(pathlib.Path('assets/mtr/mtr_custom_resources.json').read_text(encoding='utf-8'))['vehicles']:
 for m in v['models']:
  p=json.loads((pathlib.Path('assets')/m['modelPropertiesResource'].replace(':','/')).read_text(encoding='utf-8'))
  displays=[x for x in p['parts'] if x.get('type')=='DISPLAY']
  if displays:
   assert m['modelResource'].endswith('/headsign.bbmodel')
   assert {x['displayType'] for x in displays}=={'DESTINATION','ROUTE_NUMBER'}
   assert all('济南地铁' not in x.get('displayDefaultText','') for x in displays)
  if m['modelResource'].endswith('.obj'):assert not any('doorZMultiplier' in t for t in p['parts'])
assert Image.open(r/'textures/atlas.png').getpixel((224,32))[3]<150
print('PASS: 40 native door parts, draw/bounds axes agree, 101 open samples each direction, 1.5 m visible aperture inside 2 m platform zone, dedicated dynamic headsigns, translucent glass alpha')
