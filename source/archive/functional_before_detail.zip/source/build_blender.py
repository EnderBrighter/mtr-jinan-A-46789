import bpy,json,pathlib,math
from mathutils import Vector
ROOT=pathlib.Path(__file__).resolve().parents[1]; data=json.loads((ROOT/'source/geometry.json').read_text())
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
mat=bpy.data.materials.new('Jinan palette');mat.use_nodes=True
img=bpy.data.images.load(str(ROOT/'assets/mtr/jinan_line4/textures/atlas.png'));img.pack();node=mat.node_tree.nodes.new('ShaderNodeTexImage');node.image=img;node.interpolation='Closest';mat.node_tree.links.new(node.outputs['Color'],mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color']);mat.node_tree.links.new(node.outputs['Alpha'],mat.node_tree.nodes.get('Principled BSDF').inputs['Alpha']);mat.blend_method='BLEND';mat.use_screen_refraction=True;mat.node_tree.nodes.get('Principled BSDF').inputs['Roughness'].default_value=.33;mat.node_tree.nodes.get('Principled BSDF').inputs['Metallic'].default_value=.25
# MTR Y up to Blender Z up: x,y,z -> x,-z,y; texture V down -> V up
for name,groups in data.items():
 col=bpy.data.collections.new(name);bpy.context.scene.collection.children.link(col)
 for group,polys in groups.items():
  verts=[];faces=[];uvs=[]
  for p in polys:
   idx=len(verts);verts.extend([(x,-z,y) for x,y,z in p['v']]);faces.append(tuple(range(idx,idx+len(p['v']))));uvs.extend([(u,1-v) for u,v in p['uv']])
  mesh=bpy.data.meshes.new(name+'_'+group);mesh.from_pydata(verts,[],faces);mesh.update();uv=mesh.uv_layers.new()
  for i,loop in enumerate(mesh.loops):uv.data[i].uv=uvs[loop.vertex_index]
  ob=bpy.data.objects.new(group,mesh);col.objects.link(ob);ob.data.materials.append(mat)
  if name!='cab':ob.hide_render=True;ob.hide_viewport=True
# add own bogies under cab
for z in [-8.5,8.5]:
 src=bpy.data.objects.get('bogie');ob=src.copy();ob.data=src.data;bpy.context.scene.collection.objects.link(ob);ob.location.y=-z;ob.hide_render=False;ob.hide_viewport=False
# render stage
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.02));stage=bpy.context.object;stage.name='Studio floor';stage_mat=bpy.data.materials.new('Studio');stage_mat.diffuse_color=(.11,.14,.16,1);stage.data.materials.append(stage_mat)
world=bpy.context.scene.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.22,.27,.30,1);world.node_tree.nodes['Background'].inputs[1].default_value=.7
for loc,power,size in [((6,8,15),2200,9),((-8,0,10),1800,10),((0,-10,12),2000,8)]:
 bpy.ops.object.light_add(type='AREA',location=loc);l=bpy.context.object;l.data.energy=power;l.data.shape='DISK';l.data.size=size;l.rotation_euler=(Vector((0,0,1.8))-l.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add();cam=bpy.context.object;bpy.context.scene.camera=cam
scene=bpy.context.scene;scene.render.engine='BLENDER_EEVEE';scene.eevee.use_gtao=True;scene.eevee.gtao_distance=3;scene.eevee.use_soft_shadows=True;scene.render.resolution_x=1600;scene.render.resolution_y=900;scene.render.resolution_percentage=100
scene.view_settings.view_transform='Standard';scene.view_settings.look='Medium High Contrast';scene.view_settings.exposure=0;scene.view_settings.gamma=1
cam.location=(22,29,13);target=Vector((0,1,1.6));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=30
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'source/jinan_line4.blend'))
scene.render.filepath=str(ROOT/'preview/cab_overview.png');bpy.ops.render.render(write_still=True)
cam.location=(5.6,19,5.1);target=Vector((0,10,2));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=8
scene.render.filepath=str(ROOT/'preview/cab_front.png');bpy.ops.render.render(write_still=True)
# open both side doors for structural review
for ob in bpy.data.collections['cab'].objects:
 if ob.name.startswith('door_'):ob.location.y=1 if '_a' in ob.name else -1
cam.location=(10,1,5);target=Vector((0,0,1.7));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=14
scene.render.filepath=str(ROOT/'preview/doors_open.png');bpy.ops.render.render(write_still=True)
