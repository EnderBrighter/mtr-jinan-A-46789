import pathlib,json,math,uuid,base64
from PIL import Image,ImageDraw,ImageFont
ROOT=pathlib.Path(__file__).resolve().parents[1]; A=ROOT/'assets/mtr/jinan_line4'; M=A/'models'; P=A/'properties'; T=A/'textures'
COLORS={'silver':'#cbd1d3','roof':'#adb8bc','green':'#a5d431','glass':'#243c46','black':'#111b22','white':'#edf0e9','floor':'#747f84','steel':'#85979d','seat':'#79b561','yellow':'#efc944','light':'#f4ffee','red':'#d52f3f','rubber':'#333a3c'}
im=Image.new('RGBA',(1024,512));dr=ImageDraw.Draw(im)
UV={}
for i,(n,c) in enumerate(COLORS.items()):
 x=i*64;dr.rectangle((x,0,x+63,63),fill=c);UV[n]=((x+32)/1024,32/512)
f='C:/Windows/Fonts/msyh.ttc';font=ImageFont.truetype(f,38);small=ImageFont.truetype(f,22)
for y,txt in [(80,'济南地铁   JINAN METRO'),(145,'4 号线   LINE 4'),(210,'0401'),(275,'请勿倚靠车门'),(340,'第一医科大学  ←  4  →  彭家庄')]:
 dr.rectangle((0,y,1023,y+58),fill='#14252e');dr.text((12,y+4),txt,font=font if y<270 else small,fill='#dcebd8')
dr.rectangle((3*64,0,4*64-1,63),fill=(36,60,70,108))
im.save(T/'atlas.png')
Image.new('RGB',(16,16),'#444b4b').save(T/'gangway.png')
class Mesh:
 def __init__(self):self.groups={};self.door_boxes=[]
 def poly(self,g,vs,c='silver',uv=None):
  self.groups.setdefault(g,[]).append({'v':vs,'uv':uv or [UV[c]]*len(vs),'c':c})
 def box(self,g,x,y,z,w,h,l,c='silver'):
  if g.startswith('door_'):self.door_boxes.append((g,x,y,z,w,h,l,c))
  v=[(x+a*w/2,y+b*h/2,z+d*l/2) for a,b,d in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
  for ids in [(0,3,2,1),(4,5,6,7),(0,4,7,3),(1,2,6,5),(3,7,6,2),(0,1,5,4)]:self.poly(g,[v[i] for i in ids],c)
 def rod(self,g,a,b,r,c='steel',n=8):
  import numpy as np
  a=np.array(a);b=np.array(b);d=b-a;d=d/float(np.linalg.norm(d));u=np.cross(d,[0,0,1])
  if float(np.linalg.norm(u))<.01:u=np.cross(d,[1,0,0])
  u=u/float(np.linalg.norm(u));v=np.cross(d,u)
  rings=[[tuple(p+r*(u*math.cos(t*math.tau/n)+v*math.sin(t*math.tau/n))) for t in range(n)] for p in [a,b]]
  self.poly(g,list(reversed(rings[0])),c);self.poly(g,rings[1],c)
  for i in range(n):j=(i+1)%n;self.poly(g,[rings[0][i],rings[0][j],rings[1][j],rings[1][i]],c)
 def write(self,name):
  lines=['# Jinan Line 4 | meters, X right Y up Z rear','mtllib jinan.mtl'];idx=1;ni=1
  for g,faces in self.groups.items():
   lines+=['g '+g,'usemtl atlas']
   for p in faces:
    for v in p['v']:lines.append('v '+' '.join(f'{q:.6f}' for q in v))
    for uv in p['uv']:lines.append('vt '+' '.join(f'{q:.6f}' for q in uv))
    # triangulate explicitly
    for j in range(1,len(p['v'])-1):
     for tri in [[0,j,j+1],[j+1,j,0]]:
      import numpy as np
      v0,v1,v2=[np.array(p['v'][k]) for k in tri];n=np.cross(v1-v0,v2-v0);length=float(np.linalg.norm(n));n=n/length if length>1e-9 else np.array([0,1,0]);lines.append('vn '+' '.join(f'{q:.6f}' for q in n));lines.append('f '+' '.join(f'{idx+k}/{idx+k}/{ni}' for k in tri));ni+=1
    idx+=len(p['v'])
  (M/(name+'.obj')).write_text('\n'.join(lines)+'\n',encoding='utf-8')
  return self.groups

def build(cab=False,panto=False):
 m=Mesh();b=m.box
 # Floor at exactly rail +1; hollow body, genuine door and window openings.
 b('interior',0,.94,0,2.84,.12,24.3,'floor')
 b('shell',0,.76,0,2.78,.25,23.6,'silver')
 # Roof cross section bevels, continuous in length
 prof=[(-1.48,3.12),(-1.45,3.38),(-1.28,3.60),(-.92,3.72),(.92,3.72),(1.28,3.60),(1.45,3.38),(1.48,3.12)]
 for (x,y),(xx,yy) in zip(prof,prof[1:]):m.poly('shell',[(x,y,-11),(xx,yy,-11),(xx,yy,12.25),(x,y,12.25)],'roof')
 b('interior',0,3.19,0,2.74,.10,23.7,'white')
 for x in [-.92,.92]:b('lights',x,3.12,0,.19,.025,23.3,'light')
 for side in [-1,1]:
  x=side*1.43
  b('shell',x,3.03,.55,.10,.27,23.4,'silver')
  b('shell',side*1.491,3.08,.55,.009,.085,23.4,'green')
  # door centers -10,-5,0,5,10, with four 3 m wall panels
  for z in [-7.5,-2.5,2.5,7.5]:
   b('shell',x,1.48,z,.12,.96,3,'silver');b('shell',side*1.494,1.30,z,.008,.11,3,'green')
   b('shell',x,2.71,z,.12,.40,3,'silver')
   for dz in [-1.40,1.40]:b('shell',x,2.17,z+dz,.12,1.02,.20,'silver')
   b('window',side*1.40,2.20,z,0,.94,2.57,'glass')
   # longitudinal seat with 6 cushion divisions, open aisle
   b('interior',side*1.05,1.37,z,.65,.12,2.6,'white')
   for k in range(6):
    zz=z-1.08+k*.432;b('interior',side*1.05,1.45,zz,.59,.07,.40,'seat');b('interior',side*1.345,1.72,zz,.055,.49,.40,'seat')
   for dz in [-1.33,1.33]:m.rod('interior',(side*.73,1.41,z+dz),(side*.73,2.12,z+dz),.027)
   m.rod('interior',(side*.85,2.92,z-1.48),(side*.85,2.92,z+1.48),.024)
   for dz in [-1,-.5,0,.5,1]:
    zz=z+dz;m.rod('interior',(side*.85,2.92,zz),(side*.85,2.69,zz),.012,'rubber')
    pts=[(side*.85,2.69,zz),(side*.85-.10,2.49,zz),(side*.85+.10,2.49,zz),(side*.85,2.69,zz)]
    for a,c in zip(pts,pts[1:]):m.rod('interior',a,c,.018,'seat')
  for i,z in enumerate([-10,-5,0,5,10]):
   # full doorway clear width 2m; panels slide 1m into pockets
   for leaf in [-1,1]:
    g=f'door_{"l" if side<0 else "r"}_{i}_{"a" if leaf<0 else "b"}';zz=z+leaf*.50
    b(g,side*1.455,1.49,zz,.075,.96,.984,'silver');b(g,side*1.455,2.01,zz,.075,.12,.984,'silver');b(g,side*1.455,2.76,zz,.075,.24,.984,'silver')
    for dz in [-.44,.44]:b(g,side*1.455,2.37,zz+dz,.075,.62,.10,'silver')
    b(g+'_glass',side*1.455,2.37,zz,.0,.60,.77,'glass');b(g,side*1.497,1.30,zz,.004,.11,.984,'green')
    b(g,side*1.498,1.89,z+leaf*.10,.004,.15,.035,'black')
   b('interior',side*1.40,1.01,z,.16,.018,1.98,'yellow')
   b('lights',side*1.49,2.99,z,.015,.05,.13,'yellow')
   # cabin pole within passenger area
   m.rod('interior',(side*.56,1.01,z),(side*.56,3.1,z),.025)
  for end in [-1,1]:
   if cab and end<0:continue
   z=end*11.65;b('shell',x,1.83,z,.12,1.66,1.30,'silver');b('shell',side*1.494,1.30,z,.008,.11,1.30,'green')
 # end wall with center opening; coupler and bellows stay within ±12.5
 for end in [-1,1]:
  if cab and end<0:continue
  z=end*12.25
  for x in [-1.15,1.15]:b('shell',x,2.02,z,.65,2.05,.10,'silver')
  b('shell',0,3.06,z,2.8,.18,.1,'silver')
  for d in range(5):
   zz=end*(12.27+d*.043)
   for x in [-.84,.84]:b('shell',x,2.02,zz,.07,2.04,.025,'rubber')
   b('shell',0,3.04,zz,1.73,.08,.025,'rubber')
  b('shell',0,.62,end*12.26,.25,.22,.46,'black')
 # underframe equipment boxes
 for z,l in [(-5.8,2.5),(-2,2.7),(2,2.6),(5.7,2.2)]:
  b('shell',0,.46,z,2.18,.40,l,'black')
  for x in [-1.1,1.1]:
   for dz in [-.7,-.35,0,.35,.7]:b('shell',x,.49,z+dz,.025,.25,.035,'steel')
 for z in [-5.0,5.0]:
  b('shell',0,3.78,z,1.92,.22,3.0,'roof')
  for dz in [-1,-.7,-.4,-.1,.2,.5,.8,1.1]:b('shell',0,3.90,z+dz,1.6,.012,.045,'black')
 if panto:
  b('shell',0,3.80,8.2,1.15,.16,1.6,'steel')
  for x in [-.42,.42]:
   m.rod('shell',(x,3.9,7.8),(x,4.18,8.7),.032,'black');m.rod('shell',(x,4.18,8.7),(x,4.48,7.8),.025,'steel')
  b('shell',0,4.5,7.8,1.55,.04,.12,'black')
 if cab:
  # Compact cab inside 1.5 m end allocation, tapered profile drawn from references.
  rings=[(-11.0,1.48,0),(-11.55,1.45,-.02),(-12.0,1.33,-.08),(-12.30,1.17,-.16)]
  cross=[(-1,.98),(-1,3.12),(-.98,3.38),(-.865,3.60),(-.622,3.72),(.622,3.72),(.865,3.60),(.98,3.38),(1,3.12),(1,.98)]
  for (z,w,dy),(zz,ww,ddy) in zip(rings,rings[1:]):
   for j in range(len(cross)-1):
    a,h=cross[j];aa,hh=cross[j+1];m.poly('shell',[(a*w,h+dy,z),(aa*w,hh+dy,z),(aa*ww,hh+ddy,zz),(a*ww,h+ddy,zz)],'silver' if j in [0,6] else 'roof')
  # front face y-dependent rake
  def front(x,y):return (x,y,-12.36+(y-1.3)*.10)
  def nosepoly(g,points,color):m.poly(g,[front(x,y) for x,y in points],color)
  nosepoly('shell',[(-1.17,1.04),(1.17,1.04),(1.22,2.05),(-1.22,2.05)],'silver')
  nosepoly('shell',[(-1.22,2.05),(1.22,2.05),(1.11,2.20),(-1.11,2.20)],'black')
  nosepoly('shell',[(-.98,3.12),(.98,3.12),(.94,3.44),(-.94,3.44)],'black')
  nosepoly('shell',[(-.13,2.20),(.13,2.20),(.13,3.12),(-.13,3.12)],'black')
  for side in [-1,1]:
   nosepoly('shell',[(side*.90,2.20),(side*1.11,2.20),(side*.98,3.12),(side*.82,3.12)],'black')
   nosepoly('window',[(side*.13,2.20),(side*.90,2.20),(side*.82,3.12),(side*.13,3.12)],'glass')
   # angular L shaped headlamp and red accents
   pts=[(side*1.02,1.96),(side*.91,1.60),(side*.50,1.40)]
   for j in range(2):
    a=front(*pts[j]);c=front(*pts[j+1]);a=(a[0],a[1],a[2]-.025);c=(c[0],c[1],c[2]-.025)
    m.rod('shell',a,c,.085,'black');m.rod('headlights',(a[0],a[1],a[2]-.082),(c[0],c[1],c[2]-.082),.040,'light');m.rod('tail_lights',(a[0]+side*.09,a[1],a[2]),(c[0]+side*.09,c[1],c[2]),.018,'red')
   # green edge climbs around the cabin side window
   m.rod('shell',(side*1.49,1.30,-11),(side*1.45,1.35,-11.5),.045,'green');m.rod('shell',(side*1.45,1.35,-11.5),(side*1.38,2.96,-11.9),.045,'green')
  b('shell',0,.93,-12.12,2.5,.35,.35,'black');b('shell',0,.65,-12.26,.36,.30,.48,'steel')
  b('window',0,2.08,-11.1,2.68,2.12,.015,'glass');b('interior',0,1.6,-11.8,1.55,.25,.46,'black')
  # label on nose, UV rectangle in atlas
  vs=[front(-.32,1.6),front(.32,1.6),front(.32,1.81),front(-.32,1.81)];vs=[(x,y,z-.03) for x,y,z in vs]
  m.poly('shell',list(reversed(vs)),'white',list(reversed([(.17,268/512),(0,268/512),(0,210/512),(.17,210/512)])))
 return m

def bogie():
 m=Mesh();b=m.box;b('bogie',0,.43,0,1.95,.25,2.80,'black')
 for z in [-.95,.95]:
  m.rod('bogie',(-1.22,.43,z),(1.22,.43,z),.09,'steel')
  for x in [-1.05,1.05]:
   m.rod('bogie',(x-.10,.43,z),(x+.10,.43,z),.40,'rubber',16)
   m.rod('bogie',(x-.105,.43,z),(x+.105,.43,z),.25,'steel',16)
 for x in [-1.15,1.15]:b('bogie',x,.55,0,.16,.29,2.60,'black')
 return m
(M/'jinan.mtl').write_text('newmtl atlas\nKd 1 1 1\nd 1\nmap_Kd mtr:jinan_line4/textures/atlas.png\n')
scenes={}
door_boxes=[]
for name,cab,panto in [('cab',True,False),('middle',False,False),('motor',False,True)]:
 mesh=build(cab,panto);scenes[name]=mesh.write(name)
 if name=='cab':door_boxes=mesh.door_boxes
scenes['bogie']=bogie().write('bogie')
(ROOT/'source/geometry.json').write_text(json.dumps(scenes),encoding='utf-8')
# BBMODEL supplies FLOOR / DOORWAY / DISPLAY: MTR's OBJ implementation handles NORMAL only.
els=[];out=[]
def cube(g,a,b):
 uid=str(uuid.uuid4());els.append({'name':g,'type':'cube','uuid':uid,'from':a,'to':b,'origin':[0,0,0],'faces':{k:{'uv':[0,0,1,1],'texture':0} for k in ['north','south','east','west','up','down']}});out.append({'name':g,'origin':[0,0,0],'uuid':str(uuid.uuid4()),'children':[uid]})
cube('floor',[-22.5,-1,-196],[22.5,0,196])
for side in [-1,1]:
 # MTR scans horizontal doorway surfaces at floor height, extending across the platform gap.
 for i,z in enumerate([-160,-80,0,80,160]):
  xa,xb=sorted([side*21.5,side*28]);cube(f'way_{side}_{i}',[xa,0,z-16],[xb,0,z+16])
cube('display',[-10,29,-196.4],[10,33,-196.4])
(M/'interaction.bbmodel').write_text(json.dumps({'meta':{'format_version':'4.9','model_format':'modded_entity','box_uv':False},'name':'interaction','resolution':{'width':1024,'height':512},'elements':els,'outliner':out,'textures':[{'id':'0','name':'atlas.png','source':'data:image/png;base64,'+base64.b64encode((T/'atlas.png').read_bytes()).decode()}]}))
def dump(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
dump(P/'origin.json',{'positionDefinitions':[{'name':'origin','positions':[{}]},{'name':'flipped','positionsFlipped':[{}]}]})
for name in ['cab','middle','motor']:
 parts=[{'names':['shell'],'positionDefinitions':['origin'],'renderStage':'EXTERIOR'},{'names':['interior'],'positionDefinitions':['origin'],'renderStage':'INTERIOR'},{'names':['window'],'positionDefinitions':['origin'],'renderStage':'INTERIOR_TRANSLUCENT'},{'names':['lights'],'positionDefinitions':['origin'],'renderStage':'LIGHT'}]
 if name=='cab':
  for g,cond in [('headlights','ON_ROUTE_FORWARDS'),('tail_lights','ON_ROUTE_BACKWARDS')]:parts.append({'names':[g],'positionDefinitions':['origin'],'renderStage':'ALWAYS_ON_LIGHT','condition':cond})
 props={'parts':parts,'modelYOffset':0,'gangwayWidth':1.6,'gangwayHeight':2.02,'gangwayYOffset':1,'gangwayZOffset':.25}
 for s in ['Inner','Outer']:
  for face in ['Side','Top','Bottom']:props[f'gangway{s}{face}Resource']='mtr:jinan_line4/textures/gangway.png'
 # OBJ is rotated 180 degrees about X by MTR before rendering/bounds.
 # The leading cab must use the flipped instance; the BBMODEL interaction axes differ.
 if name=='cab':
  for part in props['parts']:part['positionDefinitions']=['flipped']
 dump(P/(name+'.json'),props)
 # mirror every component by using positionDefinitions flipped
 props2=json.loads(json.dumps(props))
 for part in props2['parts']:
  part['positionDefinitions']=['origin'] if name=='cab' else ['flipped']
  if name=='cab' and part.get('condition') in ['ON_ROUTE_FORWARDS','ON_ROUTE_BACKWARDS']:part['condition']='ON_ROUTE_BACKWARDS' if part['condition']=='ON_ROUTE_FORWARDS' else 'ON_ROUTE_FORWARDS'
 dump(P/(name+'_reverse.json'),props2)
dump(P/'bogie.json',{'parts':[{'names':['bogie'],'positionDefinitions':['origin'],'renderStage':'EXTERIOR'}],'modelYOffset':0})
for rev in [False,True]:
 parts=[{'names':['floor'],'positionDefinitions':['flipped' if rev else 'origin'],'type':'FLOOR'}]
 parts +=[{'names':[f'way_{side}_{i}'],'positionDefinitions':['flipped' if rev else 'origin'],'type':'DOORWAY'} for side in [-1,1] for i in range(5)]
 dump(P/('interaction_reverse.json' if rev else 'interaction.json'),{'parts':parts,'modelYOffset':1})
p0=json.loads((P/'interaction.json').read_text(encoding='utf-8'));p0['parts']=[p for p in p0['parts'] if p.get('type')!='DISPLAY'];dump(P/'interaction_middle.json',p0)
# MTR native cube convention is (-OBJ.x, OBJ.y, -OBJ.z), in 1/16 m units.
# Use one import path for moving door meshes and their interaction bounds.
door_elements=[];door_groups={}
for g,x,y,z,w,h,l,c in door_boxes:
 uid=str(uuid.uuid4());cx,cy,cz=-x*16,y*16,-z*16
 u,v=UV[c];uv=[u*1024-1,v*512-1,u*1024+1,v*512+1]
 el={'name':g,'type':'cube','uuid':uid,'from':[cx-w*8,cy-h*8,cz-l*8],'to':[cx+w*8,cy+h*8,cz+l*8],'origin':[0,0,0],'box_uv':True,'shade':True,'uv_offset':[int(u*1024-28),4],'faces':{k:{'uv':uv,'texture':0} for k in ['north','south','east','west','up','down']}}
 door_elements.append(el);door_groups.setdefault(g,[]).append(uid)
dump(M/'doors.bbmodel',{'meta':{'format_version':'4.9','model_format':'modded_entity','box_uv':False},'name':'doors','resolution':{'width':1024,'height':512},'elements':door_elements,'outliner':[{'name':g,'origin':[0,0,0],'uuid':str(uuid.uuid4()),'children':ids} for g,ids in door_groups.items()],'textures':[{'id':'0','name':'atlas.png','source':'data:image/png;base64,'+base64.b64encode((T/'atlas.png').read_bytes()).decode()}]})
for reverse in [False,True]:
 parts=[]
 for g in door_groups:
  leaf=g.split('_')[3];parts.append({'names':[g],'positionDefinitions':['flipped' if reverse else 'origin'],'renderStage':'INTERIOR_TRANSLUCENT' if g.endswith('_glass') else 'INTERIOR','doorZMultiplier':16 if leaf=='a' else -16,'doorAnimationType':'STANDARD'})
 dump(P/('doors_reverse.json' if reverse else 'doors.json'),{'parts':parts,'modelYOffset':0})

def model(name,props=None,bb=False):return {'modelResource':f'mtr:jinan_line4/models/{name}.{"bbmodel" if bb else "obj"}','textureResource':'mtr:jinan_line4/textures/atlas.png','modelPropertiesResource':f'mtr:jinan_line4/properties/{props or name}.json','positionDefinitionsResource':'mtr:jinan_line4/properties/origin.json','flipTextureV':False}
vehicles=[]
for id,label,mesh,rev in [('tc','头车 Tc','cab',False),('m','中间动车 M','middle',False),('mp','受电弓动车 Mp','motor',False),('tc_reverse','尾车 Tc（反向）','cab',True)]:
 v={'id':'jinan_line4_'+id,'name':'济南地铁4号线 | '+label,'color':'A5D431','transportMode':'TRAIN','width':3,'length':25,'couplingPadding1':0,'couplingPadding2':0,'bogie1Position':-8.5,'bogie2Position':8.5,'hasGangway1':mesh!='cab' or rev,'hasGangway2':mesh!='cab' or not rev,'tags':['family:jinan_line4','iso_3166:CN','doors:5','length:25m'],'models':[model(mesh,mesh+('_reverse' if rev else '')),model('doors','doors_reverse' if mesh=='cab' and not rev else 'doors',True),model('interaction','interaction_reverse' if rev else ('interaction' if mesh=='cab' else 'interaction_middle'),True)],'bogie1Models':[model('bogie')],'bogie2Models':[model('bogie')],'legacySpeedSoundBaseResource':'sp1900','legacySpeedSoundCount':120,'legacyDoorSoundBaseResource':'sp1900','legacyDoorCloseSoundTime':.5}
 vehicles.append(v)
dump(ROOT/'assets/mtr/mtr_custom_resources.json',{'vehicles':vehicles,'signs':[],'rails':[],'objects':[],'lifts':[]})
dump(ROOT/'pack.mcmeta',{'pack':{'pack_format':22,'description':'济南地铁4号线 · 青山绿 | MTR 4.0.5 · 25m A型车'}})
icon=Image.new('RGB',(128,128),'#14252e');d=ImageDraw.Draw(icon);d.rounded_rectangle((24,16,104,106),18,fill='#cbd1d3');d.rounded_rectangle((30,25,98,68),8,fill='#243c46');d.line((28,79,100,79),fill='#a5d431',width=6);d.text((52,28),'4',font=font,fill='white');d.ellipse((35,87,45,97),fill='white');d.ellipse((83,87,93,97),fill='white');icon.save(ROOT/'pack.png')
print('Generated',len(vehicles),'vehicle definitions;',sum(len(v) for v in scenes.values()),'mesh groups')
