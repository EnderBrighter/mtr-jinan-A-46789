"""Photo-led Jinan Line 4 geometry. All dimensions metres, Z along carriage.
The 1.5 m end allocations include the cab and half connections; car pitch stays 25 m.
"""
import math

DOORS=(-10,-5,0,5,10)
PANEL_CENTRES=(-7.5,-2.5,2.5,7.5)
END=12.24

def build(Mesh,cab=False,panto=False):
 m=Mesh();b=m.box
 def poly(g,vs,c):m.poly(g,vs,c)
 def strip(g,points,w,c):
  # Ribbon lying in side plane; points are 3D, offset within YZ.
  for a,d in zip(points,points[1:]):
   dy,dz=d[1]-a[1],d[2]-a[2];length=math.hypot(dy,dz);oy,oz=-dz/length*w/2,dy/length*w/2
   poly(g,[(a[0],a[1]+oy,a[2]+oz),(d[0],d[1]+oy,d[2]+oz),(d[0],d[1]-oy,d[2]-oz),(a[0],a[1]-oy,a[2]-oz)],c)
 def section(g,points,z0,z1,c):
  # Extrude a convex XY profile along the carriage, with end caps.
  for i in range(len(points)):
   a,d=points[i],points[(i+1)%len(points)];poly(g,[(a[0],a[1],z0),(d[0],d[1],z0),(d[0],d[1],z1),(a[0],a[1],z1)],c)
  poly(g,[(x,y,z0) for x,y in reversed(points)],c);poly(g,[(x,y,z1) for x,y in points],c)
 def round_side(g,side,z,y,l,h,r,c,x=1.483):
  pts=[]
  for zz,yy,start in [(z+l/2-r,y+h/2-r,0),(z-l/2+r,y+h/2-r,90),(z-l/2+r,y-h/2+r,180),(z+l/2-r,y-h/2+r,270)]:
   for k in range(5):
    t=math.radians(start+k*22.5);pts.append((side*x,yy+r*math.sin(t),zz+r*math.cos(t)))
  poly(g,pts,c)
 def side_window(side,z,l=2.54):
  # Black continuous window band, rubber perimeter, aluminium lip and recessed glazing.
  x=side*1.478
  b('shell',x,1.865,z,.026,.13,l+.24,'black');b('shell',x,2.965,z,.026,.19,l+.24,'black')
  for dz in [-l/2-.08,l/2+.08]:b('shell',x,2.42,z+dz,.026,1.0,.16,'black')
  # Rounded black corner backing only around the true aperture.
  for dz in [-l/2+.03,l/2-.03]:b('shell',x,2.42,z+dz,.026,1.0,.06,'black')
  round_side('window',side,z,2.40,l,.98,.10,'glass',x=1.395)
  for zz in [z-l/2,z+l/2]:b('interior',side*1.353,2.40,zz,.035,1.05,.035,'steel')
  b('interior',side*1.353,1.88,z,.04,.035,l,'steel');b('interior',side*1.353,2.92,z,.04,.035,l,'steel')
 # Completely closed floor and roof envelopes at the car ends.
 floor_start=-11.0 if cab else -END
 b('interior',0,.945,(floor_start+END)/2,2.78,.11,END-floor_start,'floor')
 if cab:b('interior',0,.945,-11.70,2.40,.11,1.40,'floor')
 chassis_start=-11.0 if cab else -END
 b('shell',0,.79,(chassis_start+END)/2,2.81,.20,END-chassis_start,'silver')
 roof=[]
 for k in range(13):
  t=math.pi*k/24;roof.append((.95+.525*math.cos(t),3.075+.595*math.sin(t)))
 roof.extend([(.475,3.67),(0,3.67),(-.475,3.67)])
 for k in range(13):
  t=math.pi/2+math.pi*k/24;roof.append((-.95+.525*math.cos(t),3.075+.595*math.sin(t)))
 z0=-11.0 if cab else -END
 for a,d in zip(roof,roof[1:]):poly('shell',[(a[0],a[1],z0),(d[0],d[1],z0),(d[0],d[1],END),(a[0],a[1],END)],'roof')
 ceiling_start=-11.0 if cab else -END
 b('interior',0,3.14,(ceiling_start+END)/2,2.71,.09,END-ceiling_start,'white')
 if cab:b('interior',0,3.14,-11.46,2.32,.08,.92,'white')
 for side in [-1,1]:
  # Curved ceiling cove joins the whole side header, including the end zones.
  section('interior',[(side*.97,3.10),(side*1.15,3.14),(side*1.37,3.01),(side*1.37,3.17),(side*.97,3.20)],ceiling_start,END,'white')
  b('lights',side*.95,3.088,(ceiling_start+END)/2,.10,.018,END-ceiling_start-.04,'light')
  b('interior',side*1.20,3.058,(ceiling_start+END)/2,.08,.015,END-ceiling_start-.05,'steel')
  for lane in [-.021,.021]:b('interior',side*1.20+lane,3.048,(ceiling_start+END)/2,.009,.008,END-ceiling_start-.08,'black')
  # Overhead rail and its short ceiling hangers.
  m.rod('interior',(side*.82,2.88,-11.8),(side*.82,2.88,11.8),.018,'steel',10)
  for z in [-10,-5,0,5,10]:m.rod('interior',(side*.82,2.88,z),(side*.82,3.08,z),.017,'steel')
  # Side header stops exactly at cab start or car end. No old 0.4 m ceiling/side-wall gap.
  centre=(z0+END)/2;length=END-z0
  b('shell',side*1.435,3.025,centre,.105,.11,length,'silver')
  b('shell',side*1.488,3.088,centre,.012,.085,length,'green')
  b('interior',side*1.365,2.995,centre,.035,.13,length,'white')
  for z in PANEL_CENTRES:
   b('shell',side*1.435,1.40,z,.105,.80,3,'silver')
   b('shell',side*1.492,1.27,z,.008,.105,3,'green')
   b('interior',side*1.353,1.42,z,.035,.84,3,'white')
   # Low sill extrusion and flush black belt around a single broad window.
   b('shell',side*1.435,1.84,z,.105,.08,3,'silver')
   for dz in [-1.39,1.39]:b('shell',side*1.435,2.43,z+dz,.105,1.10,.22,'black')
   side_window(side,z)
   # Sculpted individual seats and continuous white shell; centre aisle is 1.4 m wide.
   section('interior',[(side*.69,1.37),(side*.70,1.45),(side*1.22,1.48),(side*1.34,1.69),(side*1.36,1.94),(side*1.40,1.94),(side*1.39,1.40)],z-1.29,z+1.29,'white')
   for k in range(6):
    zz=z-1.075+k*.43;colour='yellow' if z==7.5 and k==5 else 'seat'
    profile=[(.72,1.44),(.74,1.47),(.93,1.49),(1.18,1.48),(1.27,1.54),(1.31,1.73),(1.30,1.91),(1.34,1.93),(1.37,1.91),(1.37,1.68),(1.32,1.49),(1.22,1.44)]
    section('interior',[(side*x,y) for x,y in profile],zz-.202,zz+.202,colour)
   for zz in [z-.9,z+.9]:b('interior',side*1.13,1.20,zz,.10,.32,.08,'steel')
   # Rounded rail at seat end, glazing windbreak and no pole in the doorway centre.
   for dz in [-1.29,1.29]:
    zz=z+dz
    path=[(side*.72,1.40,zz),(side*.69,1.65,zz),(side*.72,1.93,zz),(side*.85,2.12,zz),(side*1.15,2.20,zz),(side*1.34,2.20,zz)]
    for a,d in zip(path,path[1:]):m.rod('interior',a,d,.021,'steel',10)
    poly('window',[(side*.75,1.46,zz),(side*1.34,1.46,zz),(side*1.34,2.15,zz),(side*.88,2.08,zz),(side*.75,1.88,zz)],'glass')
   # Reduced-scale triangular straps, softened corners represented by ten-sided tubes.
   for dz in [-.9,-.45,0,.45,.9]:
    zz=z+dz;m.rod('interior',(side*.82,2.88,zz),(side*.82,2.69,zz),.009,'rubber',6)
    pts=[(side*.82,2.69,zz),(side*.82-.075,2.54,zz),(side*.82-.065,2.515,zz),(side*.82+.065,2.515,zz),(side*.82+.075,2.54,zz),(side*.82,2.69,zz)]
    for a,d in zip(pts,pts[1:]):m.rod('interior',a,d,.012,'seat',8)
  for i,z in enumerate(DOORS):
   # Native moving leaf: geometry kept as cuboids for MTR's stable door path.
   for leaf in [-1,1]:
    g=f'door_{"l" if side<0 else "r"}_{i}_{"a" if leaf<0 else "b"}';zz=z+leaf*.50
    b(g,side*1.455,1.10875,zz,.075,.2175,.984,'silver');b(g,side*1.455,1.55125,zz,.075,.4575,.984,'silver')
    b(g,side*1.455,1.27,zz,.075,.105,.984,'green')
    b(g,side*1.455,2.925,zz,.075,.15,.984,'black')
    b(g,side*1.455,1.83,zz,.075,.10,.984,'black')
    for dz in [-.441,.441]:b(g,side*1.455,2.37,zz+dz,.075,1.0,.102,'black')
    b(g+'_glass',side*1.455,2.37,zz,0,.98,.78,'glass')
    # Fine aluminium seam, rubber closing seal and recessed emergency handle.
    b(g,side*1.496,1.50,z+leaf*.008,.004,.97,.016,'rubber')
    b(g,side*1.495,1.75,z+leaf*.10,.005,.12,.026,'black')
    b(g,side*1.492,1.04,zz,.005,.04,.984,'steel')
   for dz in [-1.018,1.018]:b('interior',side*1.348,2.0,z+dz,.045,1.98,.032,'steel')
   b('interior',side*1.38,1.003,z,.18,.006,1.99,'yellow')
   b('shell',side*1.485,3.015,z,.015,.035,.14,'rubber')
   b('lights',side*1.497,3.015,z,.006,.022,.09,'yellow')
   # LCD housing inside above each door: left blank for later route-specific content.
   b('interior',side*1.338,3.025,z,.045,.17,1.70,'black')
   b('interior',side*1.310,3.025,z,.005,.115,1.57,'glass')
   for zz in [z-1.17,z+1.17]:
    m.rod('interior',(side*.73,1.02,zz),(side*.73,2.62,zz),.019,'steel',10)
    m.rod('interior',(side*.73,2.62,zz),(side*.82,2.88,zz),.019,'steel',10)
  # Closed full-height end side panels, with cabinet seams and interior colour.
  for end in [-1,1]:
   if cab and end<0:continue
   zz=end*(11+END)/2;ll=END-11
   b('shell',side*1.435,1.40,zz,.105,.80,ll,'silver')
   b('shell',side*1.435,2.425,zz,.105,1.25,ll,'black')
   b('shell',side*1.492,1.27,zz,.008,.105,ll,'green')
   b('interior',side*1.353,2.0,zz,.035,2.0,ll,'white')
   b('interior',side*1.329,2.0,end*11.22,.004,1.90,.012,'steel')
 # Ring bulkhead + continuous floor, ceiling and corrugated inner bellows.
 for end in [-1,1]:
  if cab and end<0:continue
  ze=end*END
  for side in [-1,1]:
   b('shell',side*1.15,2.05,ze,.65,2.10,.10,'silver')
   b('interior',side*1.15,2.05,ze-end*.07,.62,2.10,.03,'white')
   b('interior',side*.815,2.07,ze-end*.085,.035,2.14,.025,'steel')
  b('shell',0,3.25,ze,2.88,.30,.10,'silver')
  m.poly('shell',[(x,y,ze) for x,y in roof],'roof')
  b('interior',0,3.10,ze-end*.065,1.66,.04,.03,'steel')
  # The whole last 0.26 m belongs to the prescribed 1.5 m end zone.
  b('interior',0,.982,end*12.37,1.64,.036,.26,'floor')
  b('interior',0,3.115,end*12.37,1.64,.06,.26,'white')
  for k in range(7):
   zz=end*(12.255+k*.037);w=.045 if k%2==0 else .03
   for side in [-1,1]:b('shell',side*.856,2.08,zz,w,2.15,.018,'rubber')
   b('shell',0,3.14,zz,1.75,.055,.018,'rubber')
  b('shell',0,.64,end*12.28,.30,.22,.44,'black')
  # visible end bellows flange and anti-climber, below passenger floor
  b('shell',0,.86,end*12.34,1.72,.08,.18,'steel')
 # Underframe: distinct converter, battery and brake housings with fasteners.
 for z,l in [(-5.7,2.3),(-2.2,2.6),(1.5,2.6),(5.4,2.4)]:
  b('shell',0,.49,z,2.16,.42,l,'black')
  for side in [-1,1]:
   b('shell',side*1.087,.50,z,.025,.32,l-.08,'roof')
   for dz in [-l/2+.12,l/2-.12]:
    b('shell',side*1.108,.50,z+dz,.012,.28,.025,'steel')
    for yy in [.40,.60]:m.rod('shell',(side*1.11,yy,z+dz),(side*1.12,yy,z+dz),.018,'steel',6)
   for dz in [-.65,-.43,-.21,.01,.23,.45,.67]:b('shell',side*1.105,.51,z+dz,.008,.16,.023,'black')
 m.rod('shell',(-.78,.73,-6.8),(-.78,.73,6.8),.026,'rubber',8)
 # HVAC units: bevelled casing, fan grilles and side louvers.
 for z in [-5.2,5.2]:
  casing=[(-1.02,3.63),(-1.02,3.76),(-.88,3.89),(.88,3.89),(1.02,3.76),(1.02,3.63)]
  section('shell',casing,z-1.65,z+1.65,'roof')
  for dz in [-.82,.82]:
   m.rod('shell',(0,3.895,z+dz),(0,3.903,z+dz),.54,'black',32)
   for k in range(13):
    xx=-.48+k*.08;half=math.sqrt(max(0,.48**2-xx**2));b('shell',xx,3.912,z+dz,.014,.012,2*half,'steel')
  for side in [-1,1]:
   for k in range(19):b('shell',side*1.021,3.745,z-1.40+k*.155,.008,.07,.035,'black')
 if panto:
  b('shell',0,3.73,8.3,1.1,.10,1.55,'steel')
  for x in [-.43,.43]:
   for z in [7.75,8.85]:m.rod('shell',(x,3.71,z),(x,3.93,z),.065,'white',10)
   m.rod('shell',(x,3.94,7.8),(x,4.20,8.65),.028,'black',10)
   m.rod('shell',(x,4.20,8.65),(x,4.48,7.85),.022,'steel',10)
  b('shell',0,4.49,7.85,1.66,.035,.16,'black')
  m.rod('shell',(-.48,3.93,8.2),(.48,3.93,8.2),.025,'steel',8)
 if cab:build_cab(m,roof,section,strip)
 return m

def build_cab(m,roof,section,strip):
 b=m.box
 # A raked, convex front surface. Nose remains entirely inside the -11 .. -12.5 m zone.
 def front(x,y):
  yy=max(0,min(1,(y-1.0)/2.65));rake=.38*yy**1.45
  return (x,y,-12.44+rake+.145*(abs(x)/1.45)**2)
 def patch(g,pts,c):m.poly(g,[front(x,y) for x,y in pts],c)
 # Join roof and front brow with closely spaced cross sections; no detached cap.
 for k in range(12):
  t=k/12;tt=(k+1)/12
  def ring(t):
   out=[]
   for x,y in roof:
    xf=x*(1-.16*t);yf=y-.065*t
    out.append((xf,yf,-11*(1-t)+front(xf,yf)[2]*t))
   return out
  a,d=ring(t),ring(tt)
  for j in range(len(roof)-1):m.poly('shell',[a[j],a[j+1],d[j+1],d[j]],'silver')
 # Silver brow closes the cap between the black mask and the shared roof outline.
 top=[(x*.84,y-.065) for x,y in roof if y-.065>=3.49]
 patch('shell',[(-.99,3.49),(.99,3.49)]+top,'silver')
 for side in [-1,1]:
  patch('shell',[(side*1.17,2.18),(side*1.239,3.01),(side*1.08,3.49),(side*.99,3.49),(side*1.03,3.22)],'silver')
 # Lower nose subdivided to follow real convex cheeks, with front centre spine.
 rows=[1.0,1.12,1.32,1.60,1.86,2.02,2.08]
 widths=[1.23,1.30,1.34,1.32,1.28,1.23,1.20]
 for i in range(len(rows)-1):
  for j in range(16):
   u=-1+2*j/16;v=-1+2*(j+1)/16
   patch('shell',[(u*widths[i],rows[i]),(v*widths[i],rows[i]),(v*widths[i+1],rows[i+1]),(u*widths[i+1],rows[i+1])],'silver')
 # Black mask around three actual glazing apertures, no opaque sheet behind them.
 patch('shell',[(-1.20,2.08),(1.20,2.08),(1.17,2.18),(-1.17,2.18)],'black')
 patch('shell',[(-1.03,3.22),(1.03,3.22),(.99,3.49),(-.99,3.49)],'black')
 for side in [-1,1]:
  patch('shell',[(side*1.03,2.18),(side*1.17,2.18),(side*1.03,3.22),(side*.91,3.22)],'black')
  patch('shell',[(side*.20,2.18),(side*.27,2.18),(side*.27,3.22),(side*.20,3.22)],'black')
  patch('window',[(side*.27,2.18),(side*1.03,2.18),(side*.91,3.22),(side*.27,3.22)],'glass')
 patch('window',[(-.20,2.33),(.20,2.33),(.20,3.04),(-.20,3.04)],'glass')
 patch('shell',[(-.20,2.18),(.20,2.18),(.20,2.33),(-.20,2.33)],'black')
 patch('shell',[(-.20,3.04),(.20,3.04),(.20,3.22),(-.20,3.22)],'black')
 # Thin rubber front door border, and windshield wipers, modelled instead of painted bars.
 for x in [-.225,.225]:
  a=front(x,2.10);d=front(x,3.34);m.rod('shell',(a[0],a[1],a[2]-.006),(d[0],d[1],d[2]-.006),.009,'rubber',6)
 for side in [-1,1]:
  for a,d in [((side*.82,2.20),(side*.50,2.70)),((side*.50,2.70),(side*.42,3.02))]:
   a=front(*a);d=front(*d);m.rod('shell',(a[0],a[1],a[2]-.018),(d[0],d[1],d[2]-.018),.009,'black',6)
  # Small upper marker-light bezel, without route-name typography on the nose.
  for x,w,c in [(side*.83,.21,'light'),(side*.58,.10,'red')]:
   v=front(x,3.32);b('shell',x,3.32,v[2]-.012,w+.025,.055,.015,'black');b('lights',x,3.32,v[2]-.023,w,.018,.008,c)
 # Blade-shaped lamp clusters: nested planar rings, clear white inner light and red edge.
 shape=[(.50,1.34),(.92,1.51),(1.09,1.99),(.91,1.87),(.78,1.60)]
 for side in [-1,1]:
  pts=[(side*x,y) for x,y in shape];cx=sum(x for x,y in pts)/len(pts);cy=sum(y for x,y in pts)/len(pts)
  def inset(scale,offset):return [(front(cx+(x-cx)*scale,cy+(y-cy)*scale)[0],front(cx+(x-cx)*scale,cy+(y-cy)*scale)[1],front(cx+(x-cx)*scale,cy+(y-cy)*scale)[2]-offset) for x,y in pts]
  m.poly('shell',inset(1.1,.014),'black');m.poly('shell',inset(.98,.020),'steel');m.poly('shell',inset(.81,.024),'roof')
  for trace in [[(.52,1.37),(.91,1.54),(1.04,1.92)],[(.64,1.45),(.86,1.56),(.96,1.81)]]:
   pp=[front(side*x,y) for x,y in trace]
   for a,d in zip(pp,pp[1:]):m.rod('headlights',(a[0],a[1],a[2]-.031),(d[0],d[1],d[2]-.031),.012,'light',8)
  # Red outer LED traces are separate from the headlight geometry.
  pp=[front(side*.49,1.31),front(side*.95,1.49),front(side*1.12,2.00)]
  for a,d in zip(pp,pp[1:]):m.rod('tail_lights',(a[0],a[1],a[2]-.029),(d[0],d[1],d[2]-.029),.008,'red',8)
 # Close and glaze cab sides. Side window surrounded by the photographed green return stripe.
 for side in [-1,1]:
  def spt(y,z):
   t=max(0,min(1,(-z-11)/1.45));return (side*(1.475-.27*t*t),y,z)
  def sidepoly(g,pts,c):m.poly(g,[spt(y,z) for y,z in pts],c)
  # Lower shoulder is a continuous ruled surface joining the rounded nose.
  for k in range(16):
   t=k/16;tt=(k+1)/16;za=-11-1.31*t;zb=-11-1.31*tt
   sidepoly('shell',[(1.0,za),(1.0,zb),(1.95,zb),(1.95,za)],'silver')
  sidepoly('shell',[(1.95,-11),(1.95,-12.31),(2.16,-12.18),(2.16,-11)],'black')
  sidepoly('shell',[(2.94,-11),(2.94,-12.11),(3.08,-12.10),(3.08,-11)],'black')
  sidepoly('shell',[(2.16,-11),(2.16,-11.11),(2.94,-11.11),(2.94,-11)],'black')
  sidepoly('shell',[(2.16,-12.18),(2.16,-12.08),(2.94,-11.97),(2.94,-12.11)],'black')
  sidepoly('window',[(2.16,-11.11),(2.16,-12.08),(2.94,-11.97),(2.94,-11.11)],'glass')
  # Cab cheeks connect both side surfaces to the corresponding edges of the nose.
  for ya,yb in zip([1.0,1.32,1.60,1.86,2.08,2.18],[1.32,1.60,1.86,2.08,2.18,3.01]):
   def wf(y):
    if y<=2.08:return 1.30
    if y<=2.18:return 1.20-(y-2.08)*.30
    if y<=3.22:return 1.17-(y-2.18)*(.14/1.04)
    return 1.03-(y-3.22)*(.04/.27)
   a=front(side*wf(ya),ya);d=front(side*wf(yb),yb)
   m.poly('shell',[spt(ya,-12.31),a,d,spt(yb,-12.11 if yb>2.08 else -12.31)],'silver')
  path=[spt(1.27,-11),spt(1.27,-11.68),spt(1.45,-11.95),spt(3.088,-12.10),spt(3.088,-11)]
  path=[(x+side*.008,y,z) for x,y,z in path];strip('shell',path,.073,'green')
  # camera/obstacle sensor next to the cab window
  v=spt(3.10,-11.24);m.rod('shell',(v[0],v[1],v[2]),(v[0]+side*.017,v[1],v[2]),.036,'black',12)
 # Anti-climber / concealed under-nose services, all inside the 25 m envelope.
 for side in [-1,1]:
  b('shell',side*.87,.94,-12.16,.58,.28,.24,'black')
  for yy in [.85,.91,.97,1.03]:b('shell',side*.87,yy,-12.292,.44,.012,.012,'steel')
 b('shell',0,.76,-12.23,.35,.26,.49,'black')
 m.rod('shell',(0,.80,-12.35),(0,.80,-12.49),.13,'steel',16)
 for side in [-1,1]:
  m.rod('shell',(side*.15,.64,-12.25),(side*.23,.53,-12.36),.025,'rubber',8)
 # Open view through a glazed cab partition, with a slim emergency door and shaped desk.
 b('interior',0,1.25,-11.03,2.67,.50,.045,'white')
 for x in [-1.31,-.42,.42,1.31]:b('interior',x,2.30,-11.04,.025,1.62,.025,'steel')
 for x,w in [(-.87,.82),(0,.79),(.87,.82)]:b('window',x,2.30,-11.04,w,1.58,0,'glass')
 b('interior',0,3.10,-11.04,2.67,.05,.045,'white')
 desk=[(-.98,1.55),(-.98,1.74),(-.70,1.86),(.70,1.86),(.98,1.74),(.98,1.55)]
 section('interior',desk,-11.95,-11.60,'steel')
 for x in [-.48,0,.48]:b('interior',x,1.875,-11.78,.31,.018,.18,'black');b('interior',x,1.888,-11.78,.24,.004,.11,'glass')
 # Vehicle number only, not a line name or destination on the front.
 vs=[front(-.16,1.65),front(.16,1.65),front(.16,1.78),front(-.16,1.78)];vs=[(x,y,z-.008) for x,y,z in vs]
 m.poly('shell',list(reversed(vs)),'white',list(reversed([(.17,268/512),(0,268/512),(0,210/512),(.17,210/512)])))

def bogie(Mesh):
 m=Mesh();b=m.box
 b('bogie',0,.49,0,1.77,.20,2.65,'black')
 for side in [-1,1]:
  # longitudinal cast frame and axle boxes
  b('bogie',side*1.10,.49,0,.14,.22,2.73,'black')
  for z in [-.94,.94]:
   m.rod('bogie',(-1.16,.42,z),(1.16,.42,z),.072,'steel',12)
   m.rod('bogie',(side*.93,.42,z),(side*1.08,.42,z),.405,'rubber',24)
   m.rod('bogie',(side*.925,.42,z),(side*1.085,.42,z),.34,'steel',24)
   m.rod('bogie',(side*.92,.42,z),(side*1.09,.42,z),.22,'black',20)
   m.rod('bogie',(side*.915,.42,z),(side*1.095,.42,z),.09,'steel',12)
   b('bogie',side*1.14,.46,z,.16,.20,.24,'roof')
   b('bogie',side*.81,.43,z+.28,.16,.26,.12,'black')
  # secondary air spring and damper
  m.rod('bogie',(side*.64,.55,0),(side*.64,.74,0),.22,'rubber',16)
  m.rod('bogie',(side*.92,.48,-.40),(side*.99,.70,.12),.025,'steel',10)
  for z in [-.94,.94]:
   # small primary suspension coils, visually distinct from the wheel flanges
   for j in range(36):
    a=j*math.tau/12;d=(j+1)*math.tau/12
    m.rod('bogie',(side*1.13+.065*math.cos(a),.53+j*.004,z+.065*math.sin(a)),(side*1.13+.065*math.cos(d),.53+(j+1)*.004,z+.065*math.sin(d)),.008,'steel',5)
 return m
